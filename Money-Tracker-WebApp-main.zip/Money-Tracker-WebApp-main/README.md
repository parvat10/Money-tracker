# Money-Tracker-WebApp

The Money Tracker WebApp using Html, css, Node.js, MongoDB.
It is used to track our daily expenses and an essential app in our daily life.

## Technologies Used:
  - HTML
  - CSS
  - JavaScript
  - Node.js
  - Express.js
  - MongoDB
## Sample Pic :

<img width="698" alt="task 2" src="https://github.com/Aarthi-NA/Money-Tracker-WebApp/assets/136803822/e62f40fc-4082-4930-9910-997083a37a56">
